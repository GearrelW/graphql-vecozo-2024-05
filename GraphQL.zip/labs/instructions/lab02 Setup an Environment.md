# Lab 2 - Setup an Environment

In this course we'll build a new Blogging application. Let's kickoff!

---

## 1. GraphQL Server

1. Create 📂 _**blogging-app**_.

1. Open it in VS Code and open a terminal: (menubar) _View, Terminal_.  
   Create new project:

   ```bash
   npm init -yes
   ```

1. Add 📂 **_src_** with 📄 **_server.js_**.  
    Copy-paste next skeleton:

   ```js
   import { ApolloServer, gql } from 'apollo-server';
   import { ApolloServerPluginLandingPageGraphQLPlayground } from 'apollo-server-core';

   // 1. data source

   // 2. schema

   // 3. resolvers

   const server = new ApolloServer({
     typeDefs,
     resolvers,
     plugins: [ApolloServerPluginLandingPageGraphQLPlayground()],
   });

   server.listen().then(() => console.log('Server running at port 4000'));
   ```

1. To restart the server automagically during development install the **`nodemon`** package:

   ```bash
   npm install nodemon --global
   ```

1. Update 📄 **_package.json_** to:

   - use **`nodemon`**
   - use the import and export statements from ES6

   ```json
   {
     ...,
     "type": "module",                    👈 add
     "scripts": {
       "start": "nodemon src/server.js"   👈 update
     },
     ...
   }
   ```

1. Install two packages:

   ```bash
   npm install apollo-server graphql
   ```

---

## 2. Data Source

The data source exists of one in-memory array **`Users`**.

Copy-paste next array:

**server.js**

```js
const users = [
  {
    id: 'u1',
    firstname: 'Joop',
    email: 'jo@infosupport.com',
    yearOfBirth: 1982,
  },
  {
    id: 'u2',
    firstname: 'Ibrahim',
    email: 'ib@infosupport.com',
    yearOfBirth: 1989,
  },
  {
    id: 'u3',
    firstname: 'Carin',
    email: 'ca@infosupport.com',
    yearOfBirth: 1988,
  },
];
```

---

## 3. Schema

Define the schema by using a tagged template literal (ES6 feature):

**server.js**

```js
const typeDefs = gql`
  type Query {    # root type
    # entry point here
  }

  # User type here
`;
```

- Define one entry point in the root type:

  | Fieldname | Type | Nullable |
  | --------- | ---- | -------- |
  | firstUser | User | no       |

<br>

- Define the User type:

  | Fieldname   | Type   | Nullable |
  | ----------- | ------ | -------- |
  | id          | ID     | no       |
  | firstname   | String | no       |
  | email       | String | yes      |
  | yearOfBirth | Int    | yes      |

---

## 4. Resolver

Whenever the client runs a query like:

```bash
firstUser {
  id
  email
}
```

... the Schema will validate the syntax and afterwards resolvers must _resolve_ the query.

Resolver **`firstUser`** should return the first user of the array. As a user only has got scalar fields (_id_, _firstname_ etc.) we don't need to code resolvers for these (Apollo like most implementations will build default resolvers in the background). Resolvers only need to be built for _objects_ like **`firstUser`**.

1. Build a resolver map which mirrors the schema. Pick the function syntax you're comfortable with:

   ```js
   const resolvers = {
     Query: {
       // firstUser: function() {
       // firstUser() {
       firstUser: () => {
         return users[0];
       },
     },
   };
   ```

   Both the Schema (typeDefs) and Resolvers are already passed as arguments to the constructor of ApolloServer:

   ```js
   const server = new ApolloServer({ typeDefs, resolvers });
   ```

1. Start the application:

   ```bash
   npm start
   ```

---

## 5. Test in Playground

1. In a browser go to: http://localhost:4000/

1. Test the **`firstUser`** entry point. Check the auto-generated documentation. Try several combination of fields. The client is in the driver's seat!

   <details>
   <summary>Test!</summary>

   ```bash
   query {
     firstUser {
       id
       firstname
       email
       yearOfBirth
     }
   }
   ```

   </details>

---

## 6. Refactor

To stay organized it would be great to split the pretty long **_`server.js`_** file into some smaller files. In Nodejs there are several strategies.  
First we will put the data source, the schema and resolvers in separate files.

### Data Source

1. In 📂 **_src_** add 📄 **_db.js_**.  
    Cut-paste the users array to this file. Instead of exporting it as _users_, let's allow for future extensions (more tables) and implement it this way:

   **db.js**

   ```js
   const users = [
     {
       id: 'u1',
       // ...
     },
   ];

   const db = {
     // 👇 add more tables in future
     users,
   };

   export default db;
   ```

1. In 📄 **_server.js_** import **`db`** just below the import of ApolloServer.

   ```js
   import db from './db.js';
   ```

1. Update one line in the resolver (add _db._)

   **server.js**

   ```js
   return db.users[0];
   ```

1. Retest.

### Schema

1. In 📂 **_src_** add 📄 **typeDefs.js\_**.  
   Cut-paste the **`typeDefs`** variable.

   The dependency **`gql`** should also move from 📄 **_server.js_** to 📄 **_typeDefs.js_**.  
   Finally export the variable:

   **typeDefs.js**

   ```js
   import { gql } from 'apollo-server';

   const typeDefs = gql`
     type Query {
       firstUser: User!
     }

     # ...
   `;

   export default typeDefs;
   ```

1. Import the schema in 📄 **_server.js_**.

   ```js
   import typeDefs from './typeDefs.js';
   ```

1. Retest.

### Resolvers

1. In 📂 **_src_** add 📄 **resolvers.js**.

1. Cut-paste the **`resolvers`** variable.
   As the resolver needs access to the 'database', move the database import statement from 📄 **_server.js_** to 📄 **_resolvers.js_**.  
   Finally export the variable:

   **resolvers.js**

   ```js
   import db from './db.js';

   const resolvers = {
     Query: {
       firstUser: () => {
         return db.users[0];
       },
     },
   };

   export default resolvers;
   ```

1. Retest.

Done! 📄 **_server.js_** has only a couple of lines left and future extensions are much easier to implement and maintain.
