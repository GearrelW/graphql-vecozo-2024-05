## Integration Testing

There are many ways to write integration tests for a GraphQL API. In this lab we'll be using the JavaScript Testing Framework **_Jest_**. To be successful, tests should be:

- **isolated** - tests don't affect each other
- **repeatable** - test results are always the same (if code doesn't change)
- **understandable**
- **structured**
- **easy** - to attract developers to build them

Let's see how all of these are implemented in the next solution!

---

1. Copy 📂 **_lab09-use-a-database_** and name it **_Integration-Tests_**.

1. Install all dependencies:

   ```bash
   npm install
   ```

1. Install Jest as developer dependency:

   ```bash
   npm install -D jest
   ```

1. As we want to use the ES6 syntax and we don't want to add additional dependencies like **_Babel_**, we'll make the next Jest configuration in 📄 **_package.json_**:

   ```json
   {
     ...
     "scripts": {
       "start": "nodemon src/server.js",
       "test": "node --experimental-vm-modules node_modules/jest/bin/jest.js --runInBand"
     },
     "jest": {
       "testEnvironment": "jest-environment-node",
       "transform": {}
     },
     ...
   }
   ```

   - **--experimental-vm-module** - use ES6 module syntax
   - **--runInBand** - run tests serially
   - **jest-environment-node** - type of test environment
   - **transform** - allow ES6 syntax: https://jestjs.io/docs/ecmascript-modules

1. Add 📂 <strong><i>\_\_tests\_\_</i></strong> as sibling of 📂 **_src_** and add 📄 **_test.js_**:

   ```js
   describe('a nice set of tests', () => {
     it('should work', () => {
       expect(10).toBe(10);
     });
   });
   ```

1. Run the test:

   ```bash
   npm test
   ```

   Nice. The test is working!

1. An instance of an Apollo Server has got the method **`executeOperation()`**. Using this method allows thorough test without starting up an HTTP server. This will make our tests easy to write and fast when executed.

1. Add 📂 **_test-setup_** as sibling of 📂 **_src_**. Add a copy of
   📄 **_server.js_**.

1. 'Undress' this file a bit. We don't need Playground and don't want to start the server:

   ```javascript
   import { ApolloServer } from 'apollo-server';

   import { createRequire } from 'module';
   const require = createRequire(import.meta.url);
   const { PrismaClient } = require('@prisma/client');
   const prisma = new PrismaClient();

   import typeDefs from '../src/typeDefs.js';
   import Query from '../src/resolvers/Query.js';
   import Mutation from '../src/resolvers/Mutation.js';
   import User from '../src/resolvers/User.js';
   import Blog from '../src/resolvers/Blog.js';
   import Comment from '../src/resolvers/Comment.js';

   export default new ApolloServer({
     typeDefs,
     resolvers: {
       Query,
       Mutation,
       User,
       Blog,
       Comment,
     },
     context: {
       prisma,
     },
   });
   ```

1. Update 📄 **_test.js_**:

    ```js
    import server from '../test-setup/server.js';
    import { gql } from 'apollo-server';

    describe('a nice set of tests', () => {
      it('get users', async () => {
        const query = gql`
          query getUsers {
            users {
              id
              firstname
              email
              birthdate
            }
          }
        `;
        const { data } = await server.executeOperation({ query });
        
        expect(data.users.length).toBe(6);
        const firstUser = {
          id: '1',
          firstname: 'Joop',
          email: 'jo@infosupport.com',
          birthdate: '1982-12-07',
        };
        expect(data.users[0]).toEqual(firstUser);
      });
    });
    ```

      * Import the server and **`gql`**.
      * Define a query using **`gql`** (as you would normally write in Playground).
      * Call **`excecuteOperation()`** on the server providing an object with the query.
      * Use **async** and **await** as this is an asynchronous call.
      * Add two tests.

1. Run the tests.

1. One strong selling point of Jest is its ability to generate a snapshot of returned data during a test and reuse this snaphot in subsequent runs.
    
    Remove the tests and simplify. Just add:

    ```js
    expect(data.users).toMatchSnapshot();
    ```

1. Run the test. A folder 📂 <strong><i>\_\_snapshots\_\_</i></strong> has been generated!  
    Check the file inside. If the data inside is correct then don't change anything and run the test again.

1. Add another test, using a mutation and variables this time.

    ```js
      it('create user', async () => {
        const query = gql`
          mutation createUser($input: CreateUserInput!) {
            createUser(input: $input) {
              id
              firstname
              email
              birthdate
            }
          }
        `;

        const variables = {
          input: {
            firstname: 'Joop',
            email: 'joop@alfa.com',
            birthdate: '2001-04-04',
          }
        };

        const { data } = await server.executeOperation({ query, variables });
        expect(data.createUser).toMatchSnapshot();
      });
      ```

1. Run the test. Check the snapshot made. Now run the test again. It should fail! As a user was added, the first snapshot with 6 users is no longer valid. 
  
    To make the tests repeatable, let's refresh the database before each test.

    a. replace ***blogging.db*** with a fresh one (📂 **_labs\db_**)  
    b. copy the db to 📂 **_test-setup_** and name it 📄 **_temp.db_**  
    c. add 📄 **_helpers.js_** to 📂 **_test-setup_** with the next logic:

    ```js
    import { copyFileSync } from 'fs';

    export function initDB() {
      copyFileSync('./test-setup/temp.db', 'blogging.db');
    }
    ```

1. Update 📄 **_test.js_** to run **`initDB()`** before each test:

    ```js
    describe('a nice set of tests', () => {
      beforeEach(() => {
        initDB();
      });

      // the tests
    });
    ```

1. Run the test. All should be fine now.

1. Write a couple of more tests yourself.

1. In the solution of this lab, the queries an mutations have been further structure in separate files for easier maintenance.



