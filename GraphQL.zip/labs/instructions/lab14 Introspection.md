# Lab 14 - Introspection

Goals:

- Improve API by adding additional comments.
- Practice 3 handy introspection queries.

---

## 1. Comments

1. Add additional comments to types to make the API easier to understand for new users.

   ```bash
   """Users can create blogs and/or comment on blogs"""
   type User {
     # ...

     """Blogs created by the user"""
     blogs: [Blog!]!

     """Comments on blogs posted by the user"""
     comments: [Comment!]!
   }
   ```

---

## 2. Introspection queries

1. Run this introspection query:

   ```bash
   query allAvailableQueries {
     __schema {
       queryType {
         fields {
           name
           description
         }
       }
     }
   }
   ```

1. Provide comments for a **`Query`** so that it will be shown by above query.

1. Run this introspection query:

   ```bash
   query enumerationValues {
     __type(name: "UserStatus") {
       kind
       name
       description
       enumValues {
         name
         description
       }
     }
   }
   ```

1. Ensure that the 4 descriptions have values.

1. Run this introspection query to detect which concrete object types are implemented by a given abstract type: 'Publishable'.

   ```bash
   query abstractTypes {
     __type(name: "Publishable") {
       kind
       name
       description
       possibleTypes {
         name
         kind
         description
       }
     }
   }
   ```

1. Write a similar introspection query to detect which concrete types are associated with the union we've build earlier.

   <details>
   <summary>Solution</summary>

   ```bash
   query abstractTypes {
     __type(name: "BlogResult") {
       kind
       name
       description
       possibleTypes {
         name
         kind
         description
       }
     }
   }
   ```

   </details>
