# Lab 12 - Custom Scalars

Our API can be further improved by implementing custom scalars.

First we'll implement a new **`EmailAddress`** scalar. If time permits you can add a second scalar **`Date`** on your own.

---

## 1. EmailAddress

1. Update user with id 4 with an (invalid) email address:

    <details>
    <summary>Test!</summary>

   ```bash
   mutation {
     updateUser(input: {
       id: 4, email: "abc"
     }) {
       id
       firstname
       email
     }
   }
   ```

    </details><br>

   The query succeeds and the database is polluted!

1. Define a new scalar and use it instead of the String scalar:

   **schema**

   ```bash
   scalar EmailAddress

   type User {
     email: EmailAddress
     // ...
   }

   input CreateUserInput {
     email: EmailAddress
     // ...
   }

   input UpdateUserInput {
     email: EmailAddress
     // ...
   }
   ```

1. In 📂 **_src_** add 📂 **_scalars_** with 📄 **_EmailAddress.js_**.

   Implement the logic for the new scalar type, including the 3 functions. Let the functions only log retrieved values to the console.

   ```js
   import { GraphQLScalarType, Kind } from 'graphql';

   const emailAddress = new GraphQLScalarType({
     name: 'EmailAddress',
     description: 'Description for EmailAddress',
     serialize(value) {
       return value;
     },
     parseValue(value) {
       console.log(value);
       return value;
     },
     parseLiteral(ast) {
       console.log(ast.value);
       return ast.value;
     },
   });

   export default emailAddress;
   ```

1. Update the server accordingly.

1. Retest the mutation. It should still run fine as the 3 functions don't validate or convert anything.

   - check the auto-generated documentation to spot the description for the new scalar
   - check what is logged to the console

1. In the test two functions were called:

   - **`serialize()`** (= result coercion)
   - **`parseLiteral()`** (= literal input coercion)

   To also test **`parseValue()`** (= value input coercion), write another test using a variable:

    <details>
    <summary>Test!</summary>

   ```bash
   mutation($input: UpdateUserInput!) {
     updateUser (input: $input) {
       id
       firstname
       email
     }
   }
   ```

   (query variables)

   ```bash
   {
     "input":
     {
       "id": 4,
       "email": "abc"
     }
   }
   ```

    </details><br>

1. Can you guess which functions need to be updated?

   First add validation in **`parseValue()`**. To check if an email is valid always use a proven library. For testing purposes the logic that web browsers implement is sufficient for our API:

   https://html.spec.whatwg.org/multipage/input.html#valid-e-mail-address

   The second green Note shows a regular expression which we can reuse.

   Update **_`parseValue()`_**:

   ```js
   const pattern =
     /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

   const description = `
     Uses validation as defined in:
     https://html.spec.whatwg.org/
   `;

   const emailAddress = new GraphQLScalarType({
     name: 'EmailAddress',
     description,
     serialize(value) {
       return value;
     },
     parseValue(value) {
       if (typeof value === 'string' && pattern.test(value)) {
         return value;
       }
       throw new Error('invalid email address!');
     },
     parseLiteral(ast) {
       return ast.value;
     },
   });
   ```

1. Run the last test again. The Mutation using variables now has got input validation. Great!

1. The first test uses literals and isn't using the validation yet.

   In **`parseLiteral()`** the **`Kind`** helper can be used to check if the ast is of type string.

   ```bash
   parseLiteral(ast) {
     if (ast.kind === Kind.STRING && pattern.test(ast.value)) {
       return ast.value;
     }
     throw new Error('invalid email address!');
   },
   ```

   Done!

---

(If time permits)

## 2. Date

There are 2 date fields in the database:

- user.yearOfBirth (currently an integer)
- blog.availableDate

1.  Build a solution where a new **`Date`** scalar is used. The expected format is 'YYYY-MM-DD'.  
    Tip: To test if a given date is a real date you can use this logic:

        ```js
        const pattern = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/;

        function validDate(input) {
          if (!pattern.test(input)) {
            return false;
          }

          const date = new Date(input);
          return input === date.toISOString().split('T')[0];
        }
        ```

1.  Extra. Although it may not be best practise, try to display all dates in another fantastic format.  
    Use something like:

        ```js
        const dt = new Date(value);
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        return dt.toLocaleString('nl-NL', options);
        ```
