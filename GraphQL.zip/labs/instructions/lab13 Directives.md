# Lab 13 - Directive

In the first part of this lab you'll practice with built-in directives: both schema and operation directives.

If time permits you'll also build one or two custom schema directives.

---

## 1. `@include(if: Boolean!)`

This _operation_ directive can be used out-of-the-box.

1. Build a query retrieving blogs. Also include creator information.

   <details>
   <summary>Test!</summary>

   ```bash
   query {
     blogs {
       title
       content
       availableDate
       creator {
         firstname
         email
       }
     }
   }
   ```

   </details><br>

1. Extend the query. Accept a non-nullable **`show`** variable with a default value of **`true`**.  
   When explicitly set to false, the field **`content`** and object **`creator`** shouldn't be retrieved.

   Solution is at the bottom of this document.

---

## 2. `@deprecated(reason: String)`

Use this _schema_ directive to deprecate a field, argument or enum value.

1.  Deprecate the field **`email`** and suggest to use **`emailAddress`** instead. Do this everywhere in the schema!

1.  Test and check the auto-generated documentation.

    <details>
    <summary>Test!</summary>

    ```bash
    query {
      users {
        id
        email
        emailAddress
      }
    }
    ```

    </details><br>

1.  The documentation has been updated but **`emailAddress`** is **`null`** when retrieved in queries.  
    Can you guess why?

    Common use case for this directive is an updated field in the database or API. To retrieve data in our scenario, just add a new **`emailAddress()`** resolver to retrieve the **`email`** field from the database.

    ```bash
    const User = {
      // ...
      emailAddress: (parent) => parent.email,
    };
    ```

1.  Retest.

---

(Only if time permits! This exercise is a little complex)

## 3. `@upper`

1. Stop the server.

1. Install 2 libraries from **`graphl-tools`**:

   ```bash
   npm install @graphql-tools/schema @graphql-tools/utils
   ```

1. Start the server.

1. To implement custom directives, we'll need an _executable schema_. We saw this earlier when practicing subscriptions.

   **server.js**

   a. Import.

   ```js
   import { makeExecutableSchema } from '@graphql-tools/schema';
   ```

   b. Make an executable schema:

   ```js
   const schema = makeExecutableSchema({
     typeDefs,
     resolvers: {
       Query,
       Mutation,
       User,
       Blog,
       Comment,
       UserStatus,
       Publishable,
       BlogResult,
       EmailAddress,
       Date,
     },
   });
   ```

   c. Use the schema in the ApolloServer constructor:

   ```js
   const server = new ApolloServer({
     schema,
     context: {
       prisma,
     },
     plugins: [ApolloServerPluginLandingPageGraphQLPlayground()],
   });
   ```

   d. Test 1 query and 1 mutation.

1. Update the schema to support the **`@upper`** directive and use it to display blog titles always in uppercase.

   **schema**

   ```bash
   directive @upper on FIELD_DEFINITION        # 👈

   type Blog implements Publishable {
     // ...
     title: String! @upper                     # 👈
   }
   ```

1. Each directive needs a so-called **`transformer()`** function.

   In 📂 **_src_** add 📂 **_directives_**. Add 📄 **_upderDirectiveTransformer.js_**.

   A transformer function iterates through a given schema searching for a given directive.  
   When a directive is spotted it will transform the data.

   Directives can be spotted at any combination of 11 locations in a GraphQL schema: `SCALAR_TYPE`, `OBJECT_TYPE`, `OBJECT_FIELD` etc.

   More info:  
   https://www.apollographql.com/docs/apollo-server/schema/creating-directives/

   For the **`@upper`** directive we'll only use **`OBJECT_FIELD`** (= a field in any object type, _except_ an input type).

1. Add the next code t
   **upperDirectiveTransformer.js**

   ```js
   import { mapSchema, getDirective, MapperKind } from '@graphql-tools/utils';
   import { defaultFieldResolver } from 'graphql';

   function upperDirectiveTransformer(schema, directiveName) {
     return mapSchema(schema, {
       // 👇 executes once for each OBJECT_FIELD
       [MapperKind.OBJECT_FIELD]: (fieldConfig) => {
         // 👇 has this field got the @upper directive?
         const upperDirective = getDirective(
           schema,
           fieldConfig,
           directiveName
         )?.[0];

         if (upperDirective) {
           // 👇 get this field's original resolver
           const { resolve = defaultFieldResolver } = fieldConfig;

           // 👇 replace the original resolver with a function that:
           //    1. calls the original resolver
           //    2. converts its result to upper case
           fieldConfig.resolve = async function (source, args, context, info) {
             const result = await resolve(source, args, context, info);
             if (typeof result === 'string') {
               return result.toUpperCase();
             }
             return result;
           };
           return fieldConfig;
         }
       },
     });
   }

   export default upperDirectiveTransformer;
   ```

1. Update the server.

   ```js
   // ...
   import upperDirectiveTransformer from './directives/upperDirectiveTransformer.js';  // 👈 add

   let schema = makeExecutableSchema({ ... });    // 👈 let instead of const

   schema = upperDirectiveTransformer(schema, 'upper');          // 👈 transform schema

   const server = new ApolloServer({ /* ... */ });

   server.listen().then(() => console.log('🚀 Server running at port 4000'));
   ```

1. Test if blog titles are always displayed in uppercase.

    <details>
    <summary>Test!</summary>

    ```bash
    query {
      blogs {
        title
      }
    }
    ```
    </details>

---

## 4. `@btw(percentage: Float!)`

Let's assume that there is the decision to change the price of blogs by a directive in the schema.  
Can you implement this by yourself?

Two hints:

- In the schema define:

  ```bash
  directive @btw(percentage: Float!) on FIELD_DEFINITION
  ```

- In the tranformer function you could use this resolve method:

  ```js
  fieldConfig.resolve = async function (source, args, context, info) {
    const result = await resolve(source, args, context, info);
    const value = parseFloat(result);

    if (Number.isNaN(value)) {
      return result;
    }

    const { percentage } = btwDirective;

    return value * (1 + percentage / 100);
  };
  ```

---

## Solution exercise 1: `@include(if: Boolean!)`

<details>
<summary>Test!</summary>

```bash
query($show: Boolean! = true) {
  blogs {
    title
    content @include(if: $show)
    availableDate
    creator @include(if:$show) {
      firstname
      email
    }
  }
}
```

(Query Variables)

```bash
{
  "show": false
}
```

</details>
