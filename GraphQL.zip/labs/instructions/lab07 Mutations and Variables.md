# Lab 7 - Mutations and Variables

One mitigation to prevent SQL injection is to send queries and variables _separated_ to the server. This concept is called parameterized queries, aka prepared statements. In the first exercise we will practice with variables.  
The remainder of the exercise are all about _mutations_.

---

## 1. Variables

1. Rerun the _`userByFirstName()`_ query. In Playground apply 3 changes to use a variable for **`namePart`**.

   Original query:

   ```bash
   query {
     usersByFirstName(namePart: "a") {
       firstname
       email
     }
   }
   ```

2. Rewrite the _`blogsByFilter`_ query to use a variable.

   Original query:

   ```bash
   query {
     blogsByFilter(input: { content: "Blog", published: true }) {
       title
       content
       published
     }
   }
   ```

---

## 2. Mutations: Add Users

Enrich the API allowing adding users.

**schema**

1. Add the **`Mutation`** root type just below the **`Query`** root type.  
   Add one mutation entry point:

   ```bash
   type Mutation {
     createUser(input: CreateUserInput!): User!
   }
   ```

1. Define the Input Object type **`CreateUserInput`**.  
   Only a subset of the **`User`** fields is needed:

   ```bash
   input CreateUserInput {
     firstname: String!
     email: String
     yearOfBirth: Int
   }
   ```

**resolver map**

1. In 📂 **_Resolvers_** add 📄 **_Mutations.js_**.

1. Copy-paste the next skeleton code:

   ```js
   const Mutation = {
     createUser: (_parent, args, { db }) => {
       return db.users[0]; // return first user as dummy for now
     },
   };

   export default Mutation;
   ```

1. In 📄 **`server.js`** import the Mutation root type:

   ```js
   // ...
   import Query from './resolvers/Query.js';
   import Mutation from './resolvers/Mutation.js'; // 👈 add line
   // ...

   const server = new ApolloServer({
     // ...
     resolvers: {
       Query,
       Mutation, // 👈 add line
       // ...
     },
     // ...
   });
   ```

1. Although no data is altered yet, test the mutation.

    <details>
    <summary>Test!</summary>

   ```bash
   mutation {
     createUser(input:{
       firstname: "Francis",
       email: "francis@live.com",
       yearOfBirth: 1992
     }) {
       id
       firstname
       email
       yearOfBirth
       blogs {
         title
       }
     }
   }
   ```

    </details>

   Don't forget the bottom part (selection set)!  
   🔔 Forgetting the bottom part is the mistake made most often!

1. Inspect **`args`**:

   **Mutation.js**

   ```js
   createUser: (_parent, args, { db }) => {
     console.log(args);       // 👈 log expression to the console
     return db.users[0];
   },
   ```

   Input properties **`firstname`**, **`email`** and **`yearOfBirth`** are available in **`args.input`**.

1. To have unique ids generated, copy-paste next code:

   **Mutation.js**

   ```js
   import crypto from 'crypto'; // build-in Nodejs library

   function UUID() {
     return crypto.randomBytes(16).toString('hex');
   }
   ```

1. Complete the code of the resolver (copy-paste):

   **Mutation.js**

   ```js
   const Mutation = {
     createUser: (_parent, args, { db }) => {
       const user = {
         id: UUID(),
         firstname: args.input.firstname,
         email: args.input.email,
         yearOfBirth: args.input.yearOfBirth,
       };

       db.users.push(user);
       return user;
     },
   };
   ```

   Above code can be enshortened syntactically by destructuring the **`args`** argument and using the JavaScript so-called _spreading_ syntax (**`...`**):

   ```js
   const Mutation = {
     createUser: (_parent, { input }, { db }) => {
       const user = { id: UUID(), ...input };
       db.users.push(user);
       return user;
     },
   };
   ```

1. Test in Playground:

   - add users: run the mutation from step 4 a couple of times
   - return a list of all users via:

     ```bash
     query {
       users {
         id
         firstname
         blogs {
           title
         }
       }
     }
     ```

1. Rewrite above query to use an $input variabele of type _`CreateUserInput`_.

---

## 3. Mutations: Update Users

1. Add an **`updateUser`** mutation to the schema which uses an input type **`UpdateUserInput`**:

   | Fieldname   | Type   | Nullable |
   | ----------- | ------ | -------- |
   | id          | ID     | no       |
   | firstname   | String | yes      |
   | email       | String | yes      |
   | yearOfBirth | Int    | yes      |

1. Implement the resolver:

   **Mutation.js**

   ```js
   updateUser: (_parent, { input }, { db }) => {
     const { id, firstname, email, yearOfBirth } = input;
     const user = db.users.find((user) => user.id === id);

     if (!user) {
       throw new Error('User not found!');
     }

     if (firstname) {
       user.firstname = firstname;
     }

     if (email) {
       user.email = email;
     }

     if (yearOfBirth) {
       user.yearOfBirth = yearOfBirth;
     }

     return user;
   },
   ```

    <details>
    <summary>Test!</summary>

   ```bash
   mutation {
     updateUser(input: {
       id: "u1",
       firstname: "Frank",
       yearOfBirth: 1988
     }) {
       id,
       firstname,
       email,
       yearOfBirth
     }
   }
   ```

    </details>

---

## 4. Mutations: Delete Users

Update the schema to allow the deletion of users.

Part of your solution is this resolver:

```js
deleteUser: (_parent, { input }, { db }) => {
  const { id } = input;
  const foundIndex = db.users.findIndex((user) => user.id === id);

  if (foundIndex === -1) {
    throw new Error('User not found!');
  }

  const user = { ... db.users[foundIndex] };    // store copy of user
  db.users.splice(foundIndex, 1);               // remove user from data source

  return user;
},
```

---

(if time permits)

## 5. Create Blogs

Similar to exercise 2, but now for blogs.  
Note that a new blog is in an unpublished state by default!

Next mutation should run fine in Playground:

```bash
mutation {
  createBlog (input: {
    title: "Blog D",
    content: "Content of Blog D",
    creatorID: "u1"
  }) {
    id
    title
    content
    published
    creator {
      id
      firstname
    }
  }
}
```

---

(if time permits)

## 6. Publish Blogs

Further extend the API so that this mutation runs as expected:

```bash
mutation {
  publishBlog(input: {
    id: "b1",
    published: true
  }) {
    id
    title
    published
  }
}
```

---

(if time permits)

## 7. Delete Blog and handle user errors

Further extend the graph so that a blog can be deleted if it has no comments yet.  
Apart from an input type, this time we'll use a separate _output object type_.

**schema**

```bash
deleteBlog(input: DeleteBlogInput!): DeleteBlogPayload!
```

The separate output object type _`DeleteBlogPayload`_ contains:

- _`blog`_ (type Blog, nullable)
- _`errorMessage`_ (type String, nullable)

**scenario 1. blog id exists + blog has no comments**

- **`blog`**: Blog
- **`errorMessage`**: null

**scenario 2. blog id doesn't exist**

- **`blog`**: null
- **`errorMessage`**: "Blog nog found!"

**scenario 3. blog id exists + blog has comments**

- **`blog`**: null
- **`errorMessage`**: "Blog contains comments!"

Test these 3 scenarios by providing a different input variable each time:

```bash
mutation ($input: DeleteBlogInput!) {
  deleteBlog(input: $input) {
    blog {
      id
      title
    }
    errorMessage
  }
}
```

Query Variables:

```json
{
  "input": {
    "id": "b3"
  }
}
```

Good luck!
