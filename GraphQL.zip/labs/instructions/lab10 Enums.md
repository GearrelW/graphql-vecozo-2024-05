# Lab 10 - Enums

Let's assume that in our app each user has got one of 4 statuses:

- **r** - Registered (pending activation)
- **a** - Active
- **d** - Disabled
- **e** - Expired

<br>

In **`blogging.db`** the table **`Users`** has a column **`status`**.

<img src="img/users-table.png">

<br>
Our API clients should benefit from an enum and we want extra validation!

---

## 1. User `status` field

1. Define the enum **`UserStatus`**.

   **schema**

   ```bash
   enum UserStatus {
     REGISTERED
     ACTIVE
     DISABLED
     EXPIRED
   }
   ```

1. Use the enum in the **`User`** type.

   ```bash
   type User {
     # ...
     status: UserStatus!
   }

   ```

1. Add an **enum resolver** (Apollo feature) to the resolver map:  
   a. In 📂 **_resolvers_** add 📂 **_enums_** with 📄 **_UserStatus.js_**

   **UserStatus.js**

   ```js
   const UserStatus = {
     REGISTERED: 'r',
     ACTIVE: 'a',
     DISABLED: 'd',
     EXPIRED: 'e',
   };

   export default UserStatus;
   ```

   b. Provide the enum to the server.

   **server.js**

   ```js
   // ...
   import UserStatus from './resolvers/enums/UserStatus.js'; // 👈

   // ...
   const server = new ApolloServer({
     typeDefs,
     resolvers: {
       UserStatus, // 👈
       // ...
     },
     // ...
   });
   // ...
   ```

    <details>
    <summary>Test!</summary>

   ```bash
   query {
     users {
       firstname
       status
       blogs {
         title
       }
     }
   }
   ```

    </details>

   A user's status always contains a primitive value. It's a leave node in the graph, so a default resolver will resolve the field.

---

## 2. Add a query **`usersByStatus()`**

1. Extend the API so that clients can query by _user status_:

   <details>
   <summary>Test!</summary>

   ```bash
   query {
     usersByStatus(status: ACTIVE) {
       firstname
       status
       blogs {
         title
         content
       }
     }
   }
   ```

   </details>

---

## 3. Extend the mutation `createUser()`

1. When a user is created, the initial status should always be 'REGISTERED'.  
   Change the mutation **`createUser()`** to cater for that.

    <details>
    <summary>Test!</summary>

   ```bash
   mutation {
     createUser(input: {
       firstname: "Bert"
       email: "bert@alfa.com"
       birthdate: "2015-02-02"
     }) {
       id
       firstname
       email
       birthdate
       status
     }
   }
   ```

    </details>

---

## 4. Add a mutation to change a user's status

1. Add a new mutation **`changeUserStatus()`**:

   - Input: object with the fields **`id`** and **`status`**
   - Output: type **`User`**

    <details>
    <summary>Test!</summary>

   ```bash
   mutation {
     changeUserStatus(input:{
       id: 1
       status: EXPIRED
     }) {
       id
       firstname
       status
     }
   }
   ```

    </details>

Ignore the fact that in a real application only certain status changes are allowed as depicted below:

<img src="img/account-statuses.png">

- REGISTERED → ACTIVE
- ACTIVE → DISABLED
- DISABLED → ACTIVE
- DISABLED → EXPIRED
