# Lab 9 - Use a Database

In this lab we'll replace the in-memory database with a real database. After installing and configuring Prisma, the biggest challenge will be updating all resolvers, one by one. Finally the old in-memory data store can be removed.

Open as a starter the solution: 📂 **lab07-mutations-and-variables**.

This lab and future labs will use a small database with similar tables as in the previous labs.

A diagram:

![ER diagram](img/er-diagram3.png)

---

## 1. Install & Configure Prisma

1. Copy 📄 **_blogging.db_** from 📂 **_db_** to the project. Make it a sibling of 📂 **_src_**.

<img src="img/bloggingdb.png" width="150" style="border: 1px solid black;">

1. Install Prisma CLI:

   ```bash
   npm install prisma --save-dev
   ```

1. Initialize a Prisma project

   ```bash
   npx prisma init
   ```

1. In 📄 **_schema.prisma_** (📂 **_prisma_**), update the db provider:

   ```json
   datasource db {
     provider = "sqlite"
     url      = env("DATABASE_URL")
   }
   ```

1. In 📄 **_.env_** set the path to the database file:

   `DATABASE_URL="file:../blogging.db"`

---

### 2. Fill Prisma Schema

1. Fill the Prisma Schema by introspecting the database.

   ```bash
   npx prisma db pull
   ```

1. Make all fields ('left column') lowercase and express <i>semantics</i> similar to the GraphQL Schema:

   **model Blogs**  
   Users ▶ creator  
   BlogsOnCountries ▶ countries  
   Comments ▶ comments

   **model BlogsOnCountries**  
   Blogs ▶ blog  
   Countries ▶ country

   **model Comments**  
   Blogs ▶ blog  
   Users ▶ commentator

   **model Countries**  
   BlogsOnCountries ▶ blogs

   **model Users**  
   Blogs ▶ blogs  
   Comments ▶ comments

---

### 3. Install Prisma Client

1. Install _Prisma Client_

   ```bash
   npm install @prisma/client
   ```

1. Read _Prisma Schema_ and generate _Prisma Client_

   ```bash
   npx prisma generate
   ```

---

### 4. Update Server

1. Update 📄 **_'server.js'_** in 📂 **_'src'_**:

   ```js
   import pkg from '@prisma/client';   // 👈 import PrismaClient
   const { PrismaClient } = pkg;
   const prisma = new PrismaClient();  // 👈 make prisma instance

   // ...

   const server = new ApolloServer({
     typeDefs,
     resolvers: { ... },
     context: {
       db,
       prisma,                         // 👈 share prisma among all resolvers
     },
   });
   ```

---

### 5. Update Query Resolvers

Now the real stuff begins!

1. **` blogs()`** in **`Query`**  
   Let's start with a simple one. Update the **`blogs()`** resolver:

   - Use **`prisma`** instead of **`db`**
   - Make the resolver asynchronous with **`async`** and **`await`**
   - Implement **`findMany()`**

     ```js
     blogs: async (_parent, _args, { prisma }) => {
       return await prisma.blogs.findMany();
     },
     ```

      <details>
        <summary>Test!</summary>
        
        ```bash
        query {
          blogs {
            id
            title
            content
            published
          }
        }
        ```
      </details>

1. **`users()`** and **`comments()`** in **`Query`**

   - Update these 2 resolvers yourself

      <details>
        <summary>Test!</summary>

     ```bash
     query {
       users {
         id
         firstname
         email
         birthdate
       }
     }
     ```

        </details>
      
        <details>
        <summary>Test!</summary>
        
        ```bash
        query {
          comments {
            id
            content
          }
        }
        ```
        </details>

1. **`comments()`** in **`Blog`**

   - Apply the same changes as done before
   - Use the **`parent`** argument in an additional **`where`** object:

     ```js
     comments: async (parent, _args, { prisma }) => {
       return prisma.comments.findMany({
         where: {
           blogid: parent.id
         }
       });
     },
     ```

      <details>
      <summary>Test!</summary>

     ```bash
     query {
       blogs {
         id
         title
         content
         published
         comments {
           id
           content
         }
       }
     }
     ```

      </details>

1. **`blogs()`** and **`comments()`** in **`User`**

   - Update these 2 resolvers yourself.

      <details>
      <summary>Test!</summary>

     ```bash
     query {
       users {
         id
         firstname
         blogs {
           title
         }
         comments {
           content
         }
       }
     }
     ```

      </details>

1. **`creator()`** in **`Blog`**

   - Apply the same changes as done before, but now use **`findUnique()`** instead of **`findMany()`**.

     ```js
     creator: async (parent, _args, { prisma }) => {
     return prisma.users.findUnique({
       where: {
         id: parent.userid
       }
     });
     ```

      <details>
      <summary>Test!</summary>

     ```bash
     query {
       blogs {
         id
         title
         creator {
           firstname
         }
         comments {
           content
         }
       }
     }
     ```

      </details>

1. **`blog()`** and **`commentator()`** in **`Comment`**

   - Update these 2 resolvers yourself.

      <details>
      <summary>Test, replace existing query with:</summary>

     ```bash
     query {
       comments {
         id
         content
         blog {
           content
         }
         commentator {
           firstname
         }
       }
     }
     ```

      </details>

1. To not lose too much time, for each remaining resolver in **`Query`** simply copy-paste:

   - Resolver

     ```js
     firstUser: async (_parent, _args, { prisma }) => {
       return await prisma.users.findFirst();
     },
     ```

      <details>
      <summary>Test!</summary>

     ```bash
     query {
       firstUser {
         id
         firstname
       }
     }
     ```

      </details>

   - Resolver

     ```js
     usersLimited: async (_parent, { first, last }, { prisma }) => {
       if ((!first && !last) || (first && last)) {
         throw new Error('Provide either a first or last argument!');
       }

       if (first < 1 || first > 10 || last < 1 || last > 10) {
         throw new Error('Provided value should be between 1 and 10!');
       }

       return await prisma.users.findMany({
         take: first ? first : -last,
       });
     };
     ```

      <details>
      <summary>Test!</summary>

     ```bash
     query {
       usersLimited(last: 2, first: 3) {
         id
         firstname
       }
     }
     ```

      </details>

   - Resolver

     ```js
     usersByFirstName: async (_parent, { namePart }, { prisma }) => {
       return await prisma.users.findMany({
         where: {
           firstname: {
             contains: namePart,
           },
         },
       });
     };
     ```

      <details>
      <summary>Test!</summary>

     ```bash
     query {
       usersByFirstName(namePart: "i") {
         id
         firstname
       }
     }

     ```

      </details>

   - Resolver

     ```js
     blogById: async (_parent, { id }, { prisma }) => {
       return await prisma.blogs.findUnique({
         where: {
           id: +id,
         },
       });
     };
     ```

      <details>
      <summary>Test!</summary>

     ```bash
     query {
       blogById(id: 3) {
         id
         title
         content
       }
     }
     ```

      </details>

   - Resolver

     ```js
     blogsByFilter: async (_parent, args, { prisma }) => {
       const where = {};

       let { title, content, published } = args.input || {};

       if (title) {
         where.title = { contains: title };
       }

       if (content) {
         where.content = { contains: content };
       }

       if (typeof published === 'boolean') {
         where.published = published ? 1 : 0;
       }

       return await prisma.blogs.findMany({ where });
     };
     ```

      <details>
      <summary>Test!</summary>

     ```bash
     query {
       blogsByFilter(input: {
         title: "C",
         content: "g",
         published: false
       }) {
         id
         title
         content
         published
       }
     }
     ```

      </details>

---

### 6. Update Mutation Resolvers

Almost there!

In the mutation resolvers similar updates are necessary. Main 3 methods to use:

```js
create({
  data: {
    /* ... */
  },
});
```

```js
update({
  data: { / * ... */ },
  where: { /* ... */ }
});
```

```js
delete {
  where: {
    /* ... */
  },
};
```

🔔 Important! In the database, ids are typed as integer. An ID field retrieved from GraphQL is a string. Convert the string via the unary plus (**`+`**).

1.  **`createUser()`**

    - Add **`async`** & **`await`** and use prisma instead of db.  
      Call the **`create()`** method on the **`users`** model.

      ```js
      createUser: async (_parent, { input }, { prisma }) => {
        const user = await prisma.users.create({
          data: {
            ...input,
          },
        });

        return user; // return the created user(!)
      };
      ```

      <details>
      <summary>Test!</summary>

      ```bash
      mutation {
        createUser(input: {
          firstname: "Steve",
          email: "steve@xyz.com",
          birthdate: "1999-01-01"
        }) {
          id
          firstname
          email
        }
      }
      ```

      </details>

1.  **`updateUser()`**

    - Call **`update()`** on the users model.

      ```js
      updateUser: async (_parent, { input }, { prisma }) => {
        const { id } = input;
        const data = { ...input };
        delete data.id;

        try {
          const user = await prisma.users.update({
            data,
            where: {
              id: +id,
            },
          });

          return user;
        } catch (err) {
          throw new Error(err.toString());
        }
      },
      ```

      <details>
      <summary>Test!</summary>

      ```bash
      mutation {
        updateUser(input: {
          id: 6,
          email: "test@test.com",
          birthdate: "2004-05-06"
        }) {
          id
          email
          firstname
          birthdate
        }
      }
      ```

      </details>

1.  Implement the **`deleteUser()`** resolver yourself.

    <details>
    <summary>Test!</summary>

    ```bash
    mutation {
      deleteUser(input:{
        id: "7"
      }) {
        id
        firstname
        email
        birthdate
      }
    }
    ```

    </details>

1.  Copy-paste the remaining resolvers:

    - Resolver

      ```js
      createBlog: async (_parent, { input }, { prisma }) => {
        const data = { ...input };
        data.published = 0;         // 👈 SQLite has no false
        data.userid = +data.creatorID;
        delete data.creatorID;

        const blog = await prisma.blogs.create({
          data,
        });

        return blog;
      },
      ```

      <details>
      <summary>Test!</summary>

      ```bash
      mutation {
        createBlog(input: {
          title: "Another Blog",
          content: "This is a new Blog",
          creatorID: "2"
        }) {
          title
          content
          creator {
            email
          }
          published
        }
      }
      ```

      </details>

    - Resolver

      ```js
      publishBlog: async (_parent, { input }, { prisma }) => {
        const published = input.published ? 1 : 0;
        const id = +input.id;

        try {
          const blog = await prisma.blogs.update({
            data: {
              published,
            },
            where: {
              id,
            },
          });

          return blog;
        } catch (err) {
          throw new Error(err.toString());
        }
      },
      ```

      <details>
      <summary>Test!</summary>

      ```bash
      mutation {
        publishBlog(input: {
          id: 1,
          published: false
        }) {
          id
          title
          published
        }
      }
      ```

      </details>

    - Resolver

      ```js
      deleteBlog: async (_parent, { input }, { prisma }) => {
        const id = +input.id;

        try {
          const deleteBlogsOnCountries = prisma.blogsOnCountries.deleteMany({
            where: {
              blogid: id,
            }
          });

          const deleteBlog = prisma.blogs.delete({
            where: {
              id,
            },
          });

          const transaction = await prisma.$transaction([deleteBlogsOnCountries, deleteBlog]);

          return {
            blog: transaction[1],
            errorMessage: null,
          };
        } catch (err) {
          if (err.code === 'P2025') {
            return {
              blog: null,
              errorMessage: 'Blog not found!',
            };
          }

          if (err.code === 'P2003') {
            return {
              blog: null,
              errorMessage: 'Blog contains comments!',
            };
          }

          return {
            blog: null,
            errorMessage: err.message,
          };
        }
      },
      ```

      Note. In the database, blog ids can exist in the table *`blogsOnCountries`*. When a blog is deleted, possible entries in this table should be deleted as well! The deletion from both tables are wrapped in a transaction to ensure that either *both* mutations take place or *none*.

    - Test the 3 scenarios:

      **scenario 1. blog id exists + blog has no comments**

      - _`blog`_: Blog
      - _`errorMessage`_: null

      **scenario 2. blog id doesn't exist**

      - _`blog`_: null
      - _`errorMessage`_: "Blog nog found!"

      **scenario 3. blog id exists + blog has comments**

      - _`blog`_: null
      - _`errorMessage`_: "Blog contains comments!"

---

### 7. Remove all superfluous code:

- 📄 **_'db.js'_**
- **`db`** related code in 📄 **_'server.js'_**
- **`UUID()`** related code in 📄 **_Mutation.js_**
