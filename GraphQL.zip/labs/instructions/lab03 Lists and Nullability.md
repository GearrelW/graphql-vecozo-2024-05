# Lab 3 - Lists and Nullability

## 1. Retrieve Lists

The API should also support a way to retrieve all users via a new entry point **`users`**.

1. Update the schema. The new entry point should always return a list (not a null value) and although the list might be empty, it should never contain null values.

1. The resolver mirrors the schema. Add a resolver for the new entry point.

1. Test in Playground.

   <details>
   <summary>Test!</summary>

   ```bash
   query {
     users {
       id
       firstname
       email
       yearOfBirth
     }
   }
   ```

   </details>

---

## 2. Nullability Quiz

Quiz time! In each of the next scenarios the data source contains different data.  
Can you predict if GraphQL will return an error or data when this request is sent:

```bash
query {
  users {
    id
    firstname
    email
    yearOfBirth
  }
}
```

1.  ```js
    const users = [
      {
        id: 'u1',
        firstname: null,
        email: 'jo@infosupport.com',
        yearOfBirth: 1982,
      },
    ];
    ```

    <details>
    <summary>Answer</summary>

    Error is returned. In the schema the field <strong><code>firstname</code></strong> is defined as non-nullable:

    ```bash
    firstname: String!
    ```

    </details><br>

1.  ```js
    const users = [
      {
        id: 'u1',
        firstname: 'Joop',
        email: null,
        yearOfBirth: null,
      },
    ];
    ```

    <details>
    <summary>Answer</summary>

    Empty array is returned. In the schema the _`users`_ field is defined as `[User!]!`

    - 1st exclamation mark = the array shouldn't contain null values
    - 2nd exclamation mark = an array should be returned (a null value is not allowed)

    </details><br>

1.  ```js
    const users = [];
    ```

    <details>
    <summary>Answer</summary>

    Empty array is returned. In the schema the <strong><code>users</code></strong> field is defined as <code>[User!]!</code>

    - 1st exclamation mark = the array shouldn't contain null values
    - 2nd exclamation mark = an array should be returned (a null value is not allowed)
    </details><br>

1.  ```js
    const users = null;
    ```

    <details>
    <summary>Answer</summary>

    Error is returned. This is a result of the 2nd exclamation mark in <code>[User!]!</code>
    </details><br>

1.  ```js
    const users = [
      {
        id: 'u1',
        firstname: 'Joop',
        email: 'jo@infosupport.com',
        yearOfBirth: 1982,
      },
      null,
    ];
    ```

    <details>
    <summary>Answer</summary>

    Error is returned. This is a result of the 1st exclamation mark in <code>[User!]!</code>
    </details>
