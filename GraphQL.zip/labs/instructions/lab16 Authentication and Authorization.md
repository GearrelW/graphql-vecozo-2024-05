# Lab 16 - Authentication and Authorization

Let's implement step by step an authentication flow and add authorization afterwards.

---

## 1. Authentication

1. As a starter use 📂 **_lab16-START-authentication-authorization_**.

   Run the solution and inspect the code:  
   - _`users`_ = private entrypoint, user needs to be logged-in
   - _`serverTime`_ = public entrypoint  

    <details>
    <summary>Test!</summary>

    ```bash
    query {
      users {
        id
        username
        city
      }
      serverTime
    }
    ```
    </details>




1. Assume the user has successfully logged on and retrieved a JSON web token from the server. From now on the user will send this token to the server with each request.

   The token is sent in the **`authorization`** header and has the format: _BEARER 12345_.

   In Playground open the HTTP HEADERS tab and add:

   ```bash
   {
       "authorization": "BEARER 12345"
   }
   ```

   This allows testing authentication.

1. The Apollo website mentions that the context of the server automatically includes the request object (**`req`**):

   https://www.apollographql.com/docs/apollo-server/api/apollo-server/

   By filling the context with a function we can inspect what the value of the authorization header is:

   ```js
   context: async ({ req }) => {
     console.log('received:', req.headers.authorization);
     return { db };
   },
   ```

1. To keep 📄 **_server.js_** as 'clean' as possible, create 📄 **_buildContext.js_** and move the function.

   **buildContext.js**

   ```js
   import db from './db.js';

   export default async (req) => {
     console.log('received:', req.headers.authorization);
     return { db };
   };
   ```

   **server.js**

   ```js
   const server = new ApolloServer({
     // ...
     context: async ({ req }) => buildContext(req),
     // ...
   });
   ```

   Test.

1. The received token needs to be validated. Add 📄 **_authHelpers.js_** and add **`getToken()`**:.

   ```js
   export function getToken(req) {
     const authHeader = req.headers.authorization;
     const token = authHeader && authHeader.split(' ')[1];
     return token;
   }
   ```

   Use this function in 📄 **_buildContext.js_**:

   ```js
   import { getToken } from './authHelpers.js'; // 👈

   export default async (req) => {
     console.log('received:', getToken(req));   // 👈
     return { db };
   };
   ```

   Test.

1. When the server considers the token as valid (because the digital signature is correct), we'll want to store a filled **`currentUser`** object in the GraphQL context. That way all resolvers can access this object.

   - If the user couldn't be validated **`currentUser`** will be **`null`**, still allowing access to **`serverTime`**.

   - If the user is validated, **`currentUser`** is a user object which also allows access to _users_.

   Add a second function to 📄 **_auth-helpers.js_**:

   ```js
   export function getToken(req) {
     /* ... */
   }

   export async function tradeTokenForUser(token) {
     // Plugin external auth library like Passport.js

     if (token !== '12345') {
       return null;
     }

     return { id: 2, username: 'Bo' };
   }
   ```

1. Update **`buildContext()`** and call **`tradeTokenForUser()`**.

   ```js
   import { getToken, tradeTokenForUser } from './authHelpers.js';
   import db from './db.js';

   export default async (req) => {
     let token = null;
     let currentUser = null;

     try {
       token = getToken(req);
       currentUser = await tradeTokenForUser(token);
       console.log(token, currentUser); // 👈 log to console
     } catch (err) {
       console.error(`Unable to authenticate using auth token: ${token}.`);
     }

     return { token, currentUser, db };
   };
   ```

   Inspect the console while testing with:  
    a. correct authorization header  
    b. incorrect authorization header  
    c. no authorization header

1. Implement authentication logic _inside_ the **`users()`** resolver:

   ```js
   users: (_parent, _args, { db, currentUser }) => {
     if (currentUser) {
       return db.users;
     }
     return [];
     // throw new Error('Unauthenticated!');
   },
   ```

   You can choose to return an empty array or raise an error.

1. Test

---

## 2. Authentication Guard

Instead of filling all resolvers with authentication logic (and later on authorization logic), a more reusable approach is building a **guard**. This is a function which checks if **`context.currentUser`** is valid and otherwise throws an error.

Only the resolvers which need to be protected can simply be wrapped with the guard.

1. Add 📄 **_authenticatedGuard.js_**:

   ```js
   export const authenticated = (next) => {
     return (root, args, context, info) => {
       if (!context.currentUser) {
         throw new Error(`Unauthenticated!`);
       }
       return next(root, args, context, info);
     };
   };
   ```

   Wrap the resolver needing protection:

   ```js
   import { authenticated } from './authenticatedGuard.js';

   const resolvers = {
     Query: {
       users: authenticated((_parent, _args, { db }) => db.users),
       serverTime: () => new Date().toISOString(),
     },
   };

   export default resolvers;
   ```

   Test the 3 scenario's from step 7.

---

## 3. Authorization Guard

1. Extend the API: add the possibility to add notes.  
   **db**

   ```js
   db.notes = [];
   ```

   **schema**

   ```bash
   type Mutation {
     createNote(content: String!): Note!
   }

   type Note {
     id: ID!
     content: String!
   }
   ```

   **resolver**

   ```js
   let sequence = 1;

   const resolvers = {
     Query: {
       /* ... */
     },
     Mutation: {
       createNote: (_parent, { content }, { db }) => {
         const note = { id: sequence++, content };
         db.notes.push(note);
         return note;
       },
     },
   };
   ```

1. Test

1. First add the **authenticated guard** to the mutation resolver and retest.

1. Assume that only logged-in users with the role 'STUDENT' are allowed to create notes. Build a second guard to protect against unauthorized access.

   a. Update 📄 **_authHelpers.js_** to return the role as well.

   ```bash
   return { id: 2, username: 'Bo', role: 'STUDENT' };
   ```

   b. Add 📄 **_authorizedGuard.js_** with a function similar to the authenticated guard but with a role as input argument:

   ```js
   export const authorized = (role) => {
     return (next) => {
       return (root, args, context, info) => {
         if (context.currentUser.role !== role) {
           throw new Error(`Unauthorized!`);
         }
         return next(root, args, context, info);
       };
     };
   };
   ```

   In the resolver add the authorized guard:

   ```js
   Mutation: {
     createNote: authenticated(
       authorized('STUDENT')(
         (_parent, { content }, { db }) => {
           const note = { id: sequence++, content };
           db.notes.push(note);
           return note;
         }
       )
     ),
   }
   ```

1. Test:

    - authentication: 3 scenario's step 7, exercise 1
    - authorization: change 'STUDENT' in 📄 **_authHelpers.js_**

---

(only when time permits)

## 4. Authorization via custom directives

An alternative to a guard would be an `@auth` schema directive which can be used throughout the schema, for example:

```bash
directive @auth(requires: Role) on FIELD_DEFINITION

enum Role {
  ADMIN
  STUDENT
}

type Query {
  users: [User!]! @auth(requires: ADMIN)
  serverTime: String!
}

type Mutation {
  createNote(content: String!): Note! @auth(requires: STUDENT)
}
```

1. Remove the 2 guards from the previous exercises and try if you can implement such a directive.  
Use the instructions in 📂 **_lab13_Directives.md_** as a guideline.  
   Alternatively you can open the solution and examine the code.
