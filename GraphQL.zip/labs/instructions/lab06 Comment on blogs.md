# Lab 6 - Comment on blogs

Users can be creator of blogs, but users can also comment on published blogs. For this purpose we will extend our data source and our graph.

In a relational database the data may be structured this way:

![ER diagram](img/er-diagram2.png)

In this lab you'll practice what you have learned in previous modules. Furthermore let's refactor the resolvers and move them to separate files. The 3rd argument of resolvers will be used as well....

---

## 1. Comment

Let's extend the graph with a new object type _`Comment`_.

1. Update the **data source**:

   (copy-paste):

   ```js
   // 👇 add this array
   const comments = [
     { id: 'c1', content: 'comment 1 on blog A', blogid: 'b1', userid: 'u2' },
     { id: 'c2', content: 'comment 2 on blog A', blogid: 'b1', userid: 'u3' },
     { id: 'c3', content: 'comment 1 on blog B', blogid: 'b2', userid: 'u1' },
     { id: 'c4', content: 'comment 2 on blog B', blogid: 'b2', userid: 'u3' },
   ];

   const db = {
     users,
     blogs,
     comments, // 👈 add this line
   };
   ```

1. Update the schema:

- Entry point:

  | Fieldname | Type    | Nullable |
  | --------- | ------- | -------- |
  | comments  | Comment | no       |

<br>

- Comment type:

  | Fieldname   | Type   | Nullable |
  | ----------- | ------ | -------- |
  | id          | ID     | no       |
  | content     | String | no       |
  | blog        | Blog   | no       |
  | commentator | User   | no       |

1. Update the resolver map.

   - a **`comments()`** resolver returning the comments array will allow for queries only containing scalar values (**`id`** and **`content`**):

     ```bash
     query {
       comments {
         id
         content
       }
     }
     ```

   - to also resolve the _`blog`_ field (an _object_ type), add a **`Comment`** property as sibling of **`Query`**, **`Blog`** and **`User`** in the resolver map.

     Within **`Comment`** add a function to resolve the **`blog`** field. Only use the **`parent`** argument of the resolver and in the body use the JavaScript array method **`find()`** as used before.  
     Now the API support queries like:

     ```bash
     query {
       comments {
         content
         blog {
           title
           creator {
             firstname
           }
         }
       }
     }
     ```

1. Add a 3rd resolver which also resolves the field **`commentator`**.

   <details>
   <summary>Test!</summary>

   ```bash
   query {
     comments {
       content
       blog {
         title
         creator {
           firstname
         }
       }
       commentator {
         firstname
       }
     }
   }
   ```

   </details>

---

## 2. Query for comments belonging to a Blog

To allow clients to retrieve comments when retrieving blogs, only the schema and resolver map needs to be updated.

1. schema: Extend the **`Blog`** type with a **`comments`** field.

2. resolver map: Mirror the schema change in the resolver map and implement the resolver function.

   <details>
   <summary>Test!</summary>

   ```bash
   query {
     blogs {
       title
       published
       comments {
         content
       }
     }
   }
   ```

   </details>

---

## 3. Refactor

📄 **`resolver.js`** is getting too large. Split it up into separate files:

1. Within 📂 **_src_** add 📂 **_resolvers_** with:  
   📄 **_Query.js_**  
   📄 **_Blog.js_**  
   📄 **_User.js_**  
   📄 **_Comment.js_**

1. Cut the **`User`** property from 📄 **_resolvers.js_** and paste it into 📄 **_User.js_**:

   **User.js**

   ```js
   User: {
     blogs: (parent) => {
       return db.blogs.filter((blog) => blog.userid === parent.id);
     },
   },
   ```

   Update the logic slightly so that it can be imported in 📄 **_server.js_** later on:

   **User.js**

   ```js
   const User = {
     blogs: (parent) => {
       return db.blogs.filter((blog) => blog.userid === parent.id);
     },
   };

   export default User;
   ```

1. Repeat the previous step for the other 3 resolver properties.

1. All 4 new files make use of the 'database'. Start each of the 4 files with the necessary import:

   ```js
   import db from '../db.js';
   ```

1. Update 📄 **_server.js_**. The 4 files need to be imported instead of 📄 **_resolver.js_** (which is no longer necessary):

   **server.js**

   ```js
   import { ApolloServer } from 'apollo-server';

   import typeDefs from './typeDefs.js';
   import Query from './resolvers/Query.js';
   import User from './resolvers/User.js';
   import Blog from './resolvers/Blog.js';
   import Comment from './resolvers/Comment.js';

   const server = new ApolloServer({
     typeDefs,
     resolvers: {
       Query,
       User,
       Blog,
       Comment,
     },
   });

   server.listen().then(() => console.log('Server ready at port 4000'));
   ```

1. Retest a couple of queries.

---

## 4. Use shared context

All resolvers share a so-called **_context_**. This is an object which is the preferred location to store information like database connection.

The context is passed once via the ApolloServer constructor and can be read by each resolver via the 3rd argument **`context`**. Let's implement.

1. Provide the 'database' via the ApolloServer constructor.

   **server.js**

   ```js
   import db from './db.js'; // 👈 import the database

   const server = new ApolloServer({
     typeDefs,
     resolvers: {
       Query,
       // User, Blog, Comment,
     },
     context: {
       // 👈 add the context object
       db, // 👈 with the database
     },
   });
   ```

1. Let's prepare for updating ~13 resolvers with a 3rd argument:

   - to specify a 3rd argument, all resolvers will need the first 2 arguments as well: **`parent`** and **`args`**.
   - when adding the 3rd argument as **`ctx`**, the logic in the resolver needs to be updated as well, we don't want to do that:

     ```js
     const Blog = {
       // add third argument   👇
       creator: (parent, args, ctx) => {
         //      👇 here we would need to add ctx.
         return ctx.db.users.find((user) => user.id === parent.userid);
       },
     };
     ```

     In JavaScript we can _destructure_ the context object as follows:

     ```js
     const Blog = {
       // destructure db         👇
       creator: (parent, args, { db }) => {
         //     👇 no need to update the logic
         return db.users.find((user) => user.id === parent.userid);
       },
     };
     ```

   - The db import statements in the 4 resolver files no longer need the db import statement.

1. Update the resolvers!

1. Retest a couple of queries.

---

(if time permits)

## 5. Query for comments given by a User

With the new architecture in place, add logic that allows clients to also show comments when showing users. Don't touch the data source.

Test with this query:

```bash
query {
  users {
    firstname
    blogs {
      title
    }
    comments {
      content
    }
  }
}
```
