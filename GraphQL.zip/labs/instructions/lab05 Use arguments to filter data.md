# Lab 5 - Use arguments to filter data

## 1. Filter users by **`firstname`**

Wouldn't it be great to allow filtering users by firstname?

1. In the schema add a new entry point **`usersByFirstName`**.

   - type: non-nullable array of non-nullable elements of type User
   - input argument: non-nullable **`namePart`** of type **`String`**

1. Implement a resolver. Tips:

   - define 2 arguments: **`parent`** and **`args`** (only latter is used)
   - use the JavaScript array methods **`filter()`** and **`includes()`**

    <details>
    <summary>Test!</summary>

    ```bash
    query {
      usersByFirstName(namePart: "a") {
        firstname
        email
      }
    }
    ```
    </details>

---

## 2. Find blog by **`id`**

1. Implement another entry point **`blogById`**. When a given **`id`** is found, the blog is returned, otherwise **`null`**.

    <details>
    <summary>Test!</summary>

    ```bash
    query {
      blogById(id: "b2") {
        id
        title
        content
        published
        creator {
          id
          firstname
        }
      }
    }
    ```
    </details>

1. Customize the schema: when no **`id`** is provided by the client, `"b1"` should be used.

    <details>
    <summary>Test!</summary>

    ```bash
    query {
      blogById {
        id
        title
        content
        published
        creator {
          id
          firstname
        }
      }
    }
    ```
    </details><br>

1. Remove all **`blogById`** logic.

---

## 3. Filter blogs on multiple attributes (input type)

1. Add the more flexible entry point **`blogsByFilter`**

   (copy-paste)

   **schema**

   ```js
   type Query {
     blogsByFilter(title: String, content: String, published: Boolean): [Blog!]!
   }
   ```

   **resolver**

   ```js
   blogsByFilter: (_parent, args) => {
     let result = db.blogs;

     if (args.title) {
       result = result.filter((blog) => blog.title.includes(args.title))
     }

     if (args.content) {
       result = result.filter((blog) => blog.content.includes(args.content))
     }

     if (args.published) {
       result = result.filter((blog) => blog.published === args.published)
     }

     return result;
   },
   ```

   If you are a JavaScript developer, feel free to optimize resolver logic.

   Questions:

   - are the 3 arguments mandatory or optional?
   - how are the 3 arguments interpreted by the resolver (do they have an AND or OR relationship)?

1. Test in Playground.

1. Rewrite the code so that a new Input Type **`BlogsFilterInput`** with the same 3 arguments is used. When used, name the argument **`input`**.

    <details>
    <summary>Test!</summary>

    ```bash
    query {
      blogsByFilter(input:{
        title: "A",
        published: true
      }) {
        id
        title
        content
        published
      }
    }
    ```
    </details>

---

(if time permits)

## 4. `first` and `last` arguments

1.  Add another entry point **`usersLimited`**. The client must provide **_either_** a **`first`** **_or_** a **`last`** argument.

    Furthermore, the value of the provided argument must be between 1 and 10.

    Return a clear error message to the client when any of the criteria haven't met.

    Tip. Use the JavaScript array method **`slice()`** to return a range of elements from an array. Examples:

    - **`arrayname.slice(0, 5)`** returns first 5 elements
    - **`arrayname.slice(-5)`** returns last 5 elements

    <details>
    <summary>Test!</summary>

    ```bash
    query {
      usersLimited {
        id
        firstname
      }
    }
    ```
    </details>

    <details>
    <summary>Test!</summary>

    ```bash
    query {
      usersLimited (first: 1, last: 2) {
        id
        firstname
      }
    }
    ```
    </details>

    <details>
    <summary>Test!</summary>

    ```bash
    query {
      usersLimited (first: 2) {
        id
        firstname
      }
    }
    ```
    </details>

    <details>
    <summary>Test!</summary>

    ```bash
    query {
      usersLimited (last: 2) {
        id
        firstname
      }
    }
    ```
    </details>
