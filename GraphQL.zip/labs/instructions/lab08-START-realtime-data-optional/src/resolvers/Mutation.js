import crypto from 'crypto';

function UUID() {
  return crypto.randomBytes(16).toString('hex');
}

const Mutation = {
  createUser: (_parent, { input }, { db }) => {
    const user = { id: UUID(), ...input };
    db.users.push(user);
    return user;
  },
  updateUser: (_parent, { input }, { db }) => {
    const { id, firstname, email, yearOfBirth } = input;
    const user = db.users.find((user) => user.id === id);

    if (!user) {
      throw new Error('User not found!');
    }

    if (firstname) {
      user.firstname = firstname;
    }

    if (email) {
      user.email = email;
    }

    if (yearOfBirth) {
      user.yearOfBirth = yearOfBirth;
    }

    return user;
  },
  createBlog: (_parent, { input }, { db }) => {
    const { title, content, creatorID } = input;
    const blog = { 
      id: UUID(), 
      title,
      content,
      published: false, 
      userid: creatorID
    };

    db.blogs.push(blog);

    return blog;
  },
};

export default Mutation;