Running a new Blogging App solution always require two steps

1. Download required dependencies by running:
npm install

2. Start the application by running:
npm start

