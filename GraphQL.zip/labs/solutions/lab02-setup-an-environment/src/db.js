const users = [
  {
    id: "u1",
    firstname: "Joop",
    email: "jo@infosupport.com",
    yearOfBirth: 1982,
  },
  {
    id: "u2",
    firstname: "Ibrahim",
    email: "ib@infosupport.com",
    yearOfBirth: 1989,
  },
  {
    id: "u3",
    firstname: "Carin",
    email: "ca@infosupport.com",
    yearOfBirth: 1988,
  },
];

const db = {
  users,
};

export default db;