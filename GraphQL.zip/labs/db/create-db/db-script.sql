PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

CREATE TABLE Users (
  id            INTEGER  PRIMARY KEY,
  firstname     TEXT     NOT NULL,
  email         TEXT     NULL,
  birthdate	TEXT  	 NULL,   
  status        TEXT     NOT NULL DEFAULT ('a')
);

INSERT INTO Users
(firstname, email, birthdate, status)
VALUES
('Joop', 'jo@infosupport.com', '1982-12-07', 'a'),
('Ibrahim', 'ib@infosupport.com', '1989-03-03', 'a'),
('Carin', 'ca@infosupport.com', '1997-04-11', 'a'),
('firstnameOfRegisteredUser', null, null, 'r'),
('firstnameOfDisabledUser', null, null, 'd'),
('firstnameOfExpiredUser', null, null, 'e');

CREATE TABLE Blogs (
  id                  INTEGER PRIMARY KEY,
  title               TEXT,
  content             TEXT,
  published           INTEGER,      -- boolean doesn't exist in SQLite
  price	              NUMERIC NULL,
  availableDate       TEXT NULL,
  availableInCountry  INTEGER,   
  userid              INTEGER NOT NULL REFERENCES Users (id)
);

INSERT INTO Blogs 
(title, content, published, price, availableDate, availableInCountry, userid)
VALUES
('blog A', 'Content of Blog A', 1, 19.99, NULL, true, 1),
('blog B', 'Content of Blog B', 1, 24.99, NULL, true, 2),
('blog C', 'Content of Blog C', 0, NULL, '2022-05-16', true, 1),
('blog D', 'Content of Blog D', 0, NULL, NULL, false, 1),
('blog E', 'Content of Blog E', 1, NULL, NULL, false, 1);


CREATE TABLE Comments (
  id        INTEGER PRIMARY KEY,
  content   TEXT,
  published INTEGER,
  blogid    INTEGER NOT NULL REFERENCES Blogs(id),
  userid    INTEGER NOT NULL REFERENCES Users(id)
);

INSERT INTO Comments
(content, published, blogid, userid)
VALUES
('comment 1 on blog A', 1, 1, 2),
('comment 2 on blog A', 1, 1, 3),
('comment 1 on blog B', 1, 2, 1),
('comment 2 on blog B', 1, 2, 3);

CREATE TABLE Countries (
  id     INTEGER PRIMARY KEY,
  name   TEXT
);

INSERT INTO Countries
(name)
VALUES
('Netherlands'), 
('Belgium'), 
('Germany');

CREATE TABLE BlogsOnCountries (
  blogid    INTEGER NOT NULL REFERENCES Blogs(id),
  countryid INTEGER NOT NULL REFERENCES Countries(id),
  PRIMARY KEY (blogid, countryid)
);

INSERT INTO BlogsOnCountries
(blogid, countryid)
VALUES
(1, 1),
(1, 2),
(2, 1),
(3, 1),
(3, 2),
(4, 2),
(4, 3),
(5, 3);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
